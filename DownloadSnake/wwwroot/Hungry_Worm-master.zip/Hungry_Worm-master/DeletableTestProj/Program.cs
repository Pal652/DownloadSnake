﻿using System.Diagnostics;
using System.Threading.Channels;
using System.Xml.Linq;
using static System.Net.Mime.MediaTypeNames;

namespace DeletableTestProj
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random();
            for (int i = 0; i < 100; i++)
            {
                Console.Write(rnd.Next());
                Console.Write(", ");
            }

            Dictionary<string, string> a = new Dictionary<string, string>();
            a["cbjds"] = "1";

            a["cbjds"] = "chd";
            Console.WriteLine(a["cbjds"]);

            List<int> ss = new List<int> { 9, 2, 3, 4, 5, 6, 7, 8 };
            ss.RemoveRange(4, ss.Count - 4);
            for (int i = 0; i < ss.Count; i++)
            {
                Console.WriteLine(ss[i].ToString() + "nxkjs");
            }


            string[,] qqq = new string[2, 4];
            Console.WriteLine(qqq.GetLength(0));

            for (int i = 0; i < qqq.GetLength(0); i++)
            {
                for (int j = 0; j < qqq.GetLength(1); j++)
                {
                    Console.WriteLine("x");
                }
                Console.WriteLine("y");
            }

            //Console.WriteLine(a.ContainsKey("bjcdnciow"));

            //Console.WriteLine(a.ContainsKey("cbjds"));

            //Dictionary<int,_> qw = new Dictionary<int,_>();
            //qw[2] = new _();
            //Console.WriteLine(qw[1].aa);

            Stopwatch sw = new Stopwatch();
            for (int i = 0; i < 20000; i++)
            {
                if (i%1000 == 0)
                {
                    Console.WriteLine(sw.ElapsedTicks);
                    sw.Restart();
                }

            }

            ss.Add(1);

            Console.WriteLine(ss[0]);

            var q = new _();
            var w = new _();
            var e = w;

            Console.WriteLine(q == w);
            Console.WriteLine(e == w);


            var map = new int[3, 5];
            for (int i = 0; i < map.GetLength(0); i++)
            {
                for (int j = 0; j < map.GetLength(1); j++)
                {
                    map[i, j] = i + j;
                    Console.Write(i + j);
                }
                Console.WriteLine();
            }


            foreach (var s in map)
            {
                Console.WriteLine(s.ToString());
            }

            int XMAX = map.GetLength(0) - 1;
            int YMAX = map.GetLength(1) - 1;

            for (int sumXY = (XMAX + YMAX); sumXY >= 0; sumXY--)
            {
                for (int X = NTZ(sumXY - YMAX); sumXY - X >= NTZ(sumXY - XMAX); X++)
                {
                    int Y = sumXY - X;
                    //Console.WriteLine($"{X},{Y};");
                    Console.Write(map[X, Y]);
                }
                Console.WriteLine();
            }


            // Combine the current directory with the relative path and get the full path
            string dirFullPath = Path.GetFullPath(Path.Combine(Directory.GetCurrentDirectory(), "../../../../Hungry_Worm/Resources/Images/TileImages/"));
            Uri fileUri = new Uri(dirFullPath + "brick.png");

            // Display the URI
            Console.WriteLine("URI: " + fileUri.AbsoluteUri);


            Uri cdw = new Uri("C:/Users/palse/source/repos/Hungry_Worm2/Hungry_Worm/Resources/Images/TileImages/brick.png");
            Uri cdw2 = new Uri("../../../../Hungry_Worm/Resources/Images/TileImages/brick.png", UriKind.Relative);
            ;
            string ax = Console.ReadLine();

            switch (ax)
            {
                case "a":
                    Console.WriteLine("1");
                    break;
                case "b":
                case "c":
                    Console.WriteLine("2");
                    break;
                default:
                    Console.WriteLine("3");
                    break;
            }


        }

        static int NTZ(int x) // negativeToZero
        {
            return (int)(x + MathF.Abs(x)) / 2;
        }

        
    }

    public class _
    {
        public int aa = 1;
    }
}