﻿using Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JsonIgnoreAttribute = Newtonsoft.Json.JsonIgnoreAttribute;

namespace Repository
{
    public static class LevelMetaData
    {
        public class Nested
        {
            static string dir = Path.GetFullPath(Path.Combine(Directory.GetCurrentDirectory(), "../../../../Hungry_Worm/Resources/Images/IndexImages/"));
            public string file = "Basic.png";

            [JsonIgnore]
            public Uri IndexImage
            {
                get
                {
                    return new Uri(dir + file);
                }
            }

            public int PlayerNum;

            public int ThreeStarSteps;
            public int TwoStarSteps;
            public int OneStarSteps;

            public int MinimalSteps;

            public bool NoHeadpush_Possible;

            public class PlayTroughLevelData
            {
                public int PersonalMinimalSteps;
                public int StarsCollected = 0; // 0..3
                public bool BunnyKilled = false;
                public bool NoHeadPushAchievement = false;
            }

            public Dictionary<string, PlayTroughLevelData> Data = new Dictionary<string, PlayTroughLevelData>(); // saveName -> SaveDataByLevel

        }


        public static Dictionary<string, Nested> Metas = new Dictionary<string, Nested>(); // levelName -> data

        // Update -> levelEditor/ save() (OK)

        // FileNull? -> no levels made yet

        public static void Save() // Exit() (OK)
        {
            if (Metas.Count == 0) return;
            string content = JsonConvert.SerializeObject(Metas);
            File.WriteAllText("../../../cd/levelsMeta.json", content);
        }

        public static void Load() // start() (OK)
        {
            try
            {
                if (File.Exists("../../../cd/levelsMeta.json"))
                {
                    string content = File.ReadAllText("../../../cd/levelsMeta.json");
                    Metas = JsonConvert.DeserializeObject<Dictionary<string, Nested>>(content);
                }
            }
            catch (Exception) { } // null
            
        }
    }
}
