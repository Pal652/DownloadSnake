﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    public static class Saves
    {
        public static List<string> SaveNames = new List<string>();

        public static void Save() // Exit() (OK)
        {
            string content = JsonConvert.SerializeObject(SaveNames);
            File.WriteAllText("../../../cd/levelSaves.json", content);
        }

        public static void Load() // start() (OK)
        {
            if (File.Exists("../../../cd/levelSaves.json"))
            {
                string content = File.ReadAllText("../../../cd/levelSaves.json");
                SaveNames = JsonConvert.DeserializeObject<List<string>>(content);
            }

        }
    }
}
