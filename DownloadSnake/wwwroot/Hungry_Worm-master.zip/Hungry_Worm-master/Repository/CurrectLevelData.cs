﻿using Models;
using Models.descendants.ByInstance;
using Models.imported;
using Newtonsoft.Json;

namespace Repository
{
    public static class CurrectLevelData // needed when level loaded
    {

        public class Nested
        {
            // on 1 position only 1 instance of a modell (so no double stones in the same XY)

            public List<InstanceTileData>[,] Map = new List<InstanceTileData>[30, 20]; // X, Y, deepness(last in list = active (foremost))

            public Nested()
            {
                for (int i = 0; i < 30; i++)
                {
                    for(int j = 0; j < 20; j++)
                    {
                        Map[i, j] = new List<InstanceTileData>();
                    }
                }

            }
        }

        public static Nested Data = new Nested();

        public static List<SnakeHead> GetAllHeads()
        {
            List<SnakeHead> h = new List<SnakeHead> ();
            foreach (var l in Data.Map)
            {
                foreach (var item in l)
                {
                    if (item.modelID == "SnakeHead")
                    {
                        h.Add((SnakeHead)item);
                    }
                }
            }
            return h;
        }

        public static void Wipe()
        {
            Data = new Nested();
        }

        public static SnakeHead BodyToHead(InstanceTileData b)
        {
            return GetHead(((SnakeBody)b).OwnerNum);
        }

        public static SnakeHead GetHead(int controllingPlayer)
        {
            var heads = GetAllHeads();
            ;
            return GetAllHeads().First(c => c.OwnerNum == controllingPlayer);
        }

        public static int PlayerNum { get { return GetAllHeads().Count; } }

        public static void AddToMap(InstanceTileData tile)
        {
            var mapPos = Data.Map[tile.MapPosXY.x, tile.MapPosXY.y];
            mapPos.Add(tile);
        }
        public static void RemoveFromMap(InstanceTileData tile)
        {
            var mapPos = Data.Map[tile.MapPosXY.x, tile.MapPosXY.y];
            InstanceTileData? tile2 = mapPos.Where(t => t.ModelID == tile.ModelID).FirstOrDefault();
            if (tile2 != null) mapPos.Remove(tile2);
        }

        public static void MoveOnMap(InstanceTileData tile, Vector2Int newPos)
        {
            RemoveFromMap(tile);
            tile.MapPosXY = newPos;
            AddToMap(tile);
        }

        public static InstanceTileData? GetFromMap(Vector2Int posXY, string ModelID)
        {
            var mapPos = Data.Map[posXY.x, posXY.y];
            return mapPos.Where(t => t.ModelID == ModelID).FirstOrDefault();
        }

        // update -> InlevelEditor (OK)

        // FileNull? -> not possible

        public static void SaveLevel(string levelName) // level editor save() (OK)
        {
            /*
            foreach (var h in GetAllHeads())
            {
                foreach (SnakeBody body in h.bodies) RemoveFromMap(body); // remove bodyes from map (b. of ref problems)
            }
            */

            var settings = new JsonSerializerSettings
            {
                TypeNameHandling = TypeNameHandling.Auto, // Include type information
                //PreserveReferencesHandling = PreserveReferencesHandling.Objects, // Preserve references
                Formatting = Formatting.Indented
            };
            string content = JsonConvert.SerializeObject(Data, settings);
            File.WriteAllText("../../../cd/Levels/" + levelName + ".json", content);
        }
        public static bool LoadLevel(string levelName) // levelEditor/ import + game/ level chosen (OK)
        {
            if (!File.Exists("../../../cd/Levels/" + levelName + ".json")) return false;

            var settings = new JsonSerializerSettings
            {
                //PreserveReferencesHandling = PreserveReferencesHandling.Objects, // Use preserved references
                TypeNameHandling = TypeNameHandling.Auto // Use type information during deserialization
            };

            string content = File.ReadAllText("../../../cd/Levels/" + levelName + ".json");
            Data = JsonConvert.DeserializeObject<Nested>(content, settings);
            /*
            foreach (var c in GetAllHeads())
            {
                foreach (SnakeBody body in c.bodies)
                {
                    AddToMap(body);
                }
            }
            */
            return true;
        }

        public static bool OutsideOfMap(Vector2Int posXY)
        {
            return posXY.x >= Data.Map.GetLength(0) ||
                   posXY.x < 0 ||
                   posXY.y < 0 ||
                   posXY.y >= Data.Map.GetLength(1);
        }
    }
}