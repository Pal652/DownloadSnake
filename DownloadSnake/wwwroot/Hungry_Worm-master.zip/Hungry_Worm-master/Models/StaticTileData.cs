﻿using Models.descendants.ByModel;

namespace Models
{
    public class StaticTileData
    {
        public string ID;
        public Uri[] ImagePathsBackGround; // animation by frame // everyvody has
        public Uri[] ImagePathsForground; // animation by frame // just coverable objects need it

        public bool DoubleState;
        public DoubleStateData? State;

        public bool pushable;
        public bool eatable;
        public string[] canFallTroughID; // what can fall trough this [for snake use SnakeHead]
        public string[] CanBePushedIntoThis;
        public bool kills;
        public bool snakeCanClimbInto;

        public bool gravitable;
        public bool floatPos;

        static internal string dirFullPath = Path.GetFullPath(Path.Combine(Directory.GetCurrentDirectory(), "../../../../Hungry_Worm/Resources/Images/TileImages/"));

        public StaticTileData(string ID, string[] ImageFiles, string[]? ImageForgroundfiles = null, DoubleStateData? state = null, bool pushable = false, bool eatable = false, string[]? canFallTroughID = null, bool kills = false, bool gravitable = false, bool controllable = false, bool snakeCanClimbInto = false, string[]? CanBePushedIntoThis = null)
        {
            this.ID = ID;

            ImagePathsBackGround = new Uri[ImageFiles.Length];
            for (int i = 0; i < ImageFiles.Length; i++) ImagePathsBackGround[i] = new Uri(dirFullPath + ImageFiles[i]);

            if (ImageForgroundfiles != null)
            {
                ImagePathsForground = new Uri[ImageForgroundfiles.Length];
                for (int i = 0; i < ImageForgroundfiles.Length; i++) ImagePathsForground[i] = new Uri(dirFullPath + ImageForgroundfiles[i]);
            }

            State = state;
            DoubleState = state != null;

            if (canFallTroughID == null) this.canFallTroughID = new string[0];
            else this.canFallTroughID = canFallTroughID;

            if (CanBePushedIntoThis == null) this.CanBePushedIntoThis = new string[0];
            else this.CanBePushedIntoThis = CanBePushedIntoThis;


            this.pushable = pushable;
            this.eatable = eatable;
            this.kills = kills;
            this.snakeCanClimbInto = snakeCanClimbInto;

            this.gravitable = gravitable;
            this.floatPos = gravitable || controllable || pushable;
        }
    }
}