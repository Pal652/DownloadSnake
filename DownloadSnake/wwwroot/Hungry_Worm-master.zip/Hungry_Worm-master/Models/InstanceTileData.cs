﻿using Models.descendants.ByInstance;
using Models.imported;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using JsonIgnoreAttribute = Newtonsoft.Json.JsonIgnoreAttribute;

namespace Models
{
    public class InstanceTileData
    {
        // <DoubleState>

        public bool active = true;
        public bool StateChanged = false;

        // </DoubleState>


        public string modelID;

        [JsonIgnore]
        public string ModelID
        {
            get
            {
                if (active) return modelID;
                else return StaticTileData.State.InactiveStatelId;
            }
        }
        [JsonIgnore]
        public StaticTileData? StaticTileData
        {
            get
            {
                if (ModelID == "null") return null;
                return ModelTiles.prefabs[ModelID];
            }
        }

        public Vector2Int MapPosXY;

        [JsonIgnore]
        public Vector2 PosXY // for UI
        {
            get
            {
                if (StaticTileData.floatPos) return floatPos;
                else return new Vector2(MapPosXY.x, MapPosXY.y);
            }
        }

        public Vector2 floatPos;
        public GravityData? GravityData = null;

        public InstanceTileData(string modelID, Vector2Int posXY)
        {
            this.modelID = modelID;
            MapPosXY = posXY;

            if (StaticTileData.gravitable) GravityData = new GravityData();
            if (StaticTileData.floatPos) floatPos = new Vector2(posXY.x, posXY.y);
        }

        //public override bool Equals(object? obj)
        //{
        //    var obj2 = obj as InstanceTileData;
        //    return (MapPosXY == obj2.MapPosXY && ModelID == obj2.ModelID);
        //}
    }
}
