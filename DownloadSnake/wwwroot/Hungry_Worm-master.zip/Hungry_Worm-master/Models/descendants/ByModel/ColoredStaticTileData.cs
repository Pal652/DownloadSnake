﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.descendants.ByModel
{
    public class ColoredStaticTileData : StaticTileData
    {
        public Uri[] AbsoluteBackgroundP;
        public Uri[] ColorableImagePaths;
        public Uri[] LinesImagePaths;
        
        public ColoredStaticTileData(string ID, string[] ImageFiles, string[] ColorableImageF, string[] LinesImageF, string[] AbsoluteBackgroundF, string[]? ImageForgroundfiles = null, DoubleStateData? state = null, bool pushable = false, bool eatable = false, string[]? canFallTroughID = null, bool kills = false, bool gravitable = false, bool controllable = false, bool snakeCanClimbInto = false, string[]? CanBePushedIntoThis = null) : base(ID, ImageFiles, ImageForgroundfiles, state, pushable, eatable, canFallTroughID, kills, gravitable, controllable, snakeCanClimbInto, CanBePushedIntoThis)
        {
            // setup uris

            ColorableImagePaths = new Uri[ColorableImageF.Length];
            for (int i = 0; i < ColorableImageF.Length; i++) ColorableImagePaths[i] = new Uri(dirFullPath + ColorableImageF[i]);

            LinesImagePaths = new Uri[LinesImageF.Length];
            for (int i = 0; i < LinesImageF.Length; i++) LinesImagePaths[i] = new Uri(dirFullPath + LinesImageF[i]);

            AbsoluteBackgroundP = new Uri[AbsoluteBackgroundF.Length];
            for (int i = 0; i < AbsoluteBackgroundF.Length; i++) AbsoluteBackgroundP[i] = new Uri(dirFullPath + AbsoluteBackgroundF[i]);
        }
        
    }
}
