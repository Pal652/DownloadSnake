﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.descendants.ByModel
{
    public class DoubleStateData // if new sub class, add to Gamelogic.StateChanger()
    {
        public string InactiveStatelId;
        public Uri[] Anims = new Uri[0];

        public DoubleStateData(string inactiveStatelId = "null", string[]? anims = null)
        {
            InactiveStatelId = inactiveStatelId;

            if (anims != null)
            {
                Anims = new Uri[anims.Length];
                for (int i = 0; i < anims.Length; i++) Anims[i] = new Uri(StaticTileData.dirFullPath + anims[i]);
            }
        }

    }
}
