﻿using Models.imported;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Models.descendants.ByInstance
{
    public class SnakeHead : ColoredInstanceTileData
    {
        public List<SnakeBody> bodies = new List<SnakeBody>();

        public SnakeHead(Vector2Int posXY, int ControllingPlayer)
        : base("SnakeHead", posXY, ControllingPlayer) { }

        public bool DeathUnder; // something what kills under a snake bodypart
    }
}
