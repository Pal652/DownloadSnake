﻿using Models.imported;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.descendants.ByInstance
{
    public class InstanceTimyTileData : InstanceTileData
    {
        public int cycleLen;
        public int activeLen;
        public int offset;

        public void SetActive(int steps)
        {
            StateChanged = active != (steps + offset) % cycleLen < activeLen;
            active ^= StateChanged;
        }

        // in editor
        public InstanceTimyTileData(string modelID, Vector2Int posXY, int cycleLen = 2, int activeLen = 1, int offset = 0) : base(modelID, posXY)
        {
            this.cycleLen = cycleLen;
            this.activeLen = activeLen;
            this.offset = offset;
        }
    }
}
