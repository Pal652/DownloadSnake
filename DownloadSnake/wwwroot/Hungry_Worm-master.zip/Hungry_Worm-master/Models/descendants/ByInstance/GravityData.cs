﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.descendants.ByInstance
{
    public class GravityData
    {
        public int fallCount; // how many units will this fall
        public bool Fix; // fix (or "Fix or under examination" for snake)
        public bool UnderExamination;
        public bool Examined;

        public bool GotDestroyed; // of the level
    }
}
