﻿using Models.imported;
using Newtonsoft.Json;
using System.Drawing;
using System.Numerics;
using System.Text.Json.Serialization;
using JsonIgnoreAttribute = Newtonsoft.Json.JsonIgnoreAttribute;

namespace Models.descendants.ByInstance
{
    public class SnakeBody : ColoredInstanceTileData
    {
        public int bodynum;

        public SnakeBody(Vector2Int posXY, int OwnerNum, int bodynum)
        : base("SnakeBody", posXY, OwnerNum, bodynum % Skins.SnakeColors[OwnerNum].Length)
        {
            this.bodynum = bodynum;
        }
    }
}