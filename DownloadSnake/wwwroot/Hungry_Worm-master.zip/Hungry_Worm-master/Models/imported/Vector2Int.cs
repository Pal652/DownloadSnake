﻿
using System;
using System.Globalization;
using System.Numerics;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Models.imported
{
    // I throw out lot of stuff from Unity's Vector2Int, and this is the result.

    // Representation of 2D vectors and points.
    [StructLayout(LayoutKind.Sequential)]
    public struct Vector2Int : IEquatable<Vector2Int>
    {
        public int x
        {
            get { return m_X; }
            set { m_X = value; }
        }


        public int y
        {
            get { return m_Y; }
            set { m_Y = value; }
        }

        private int m_X;
        private int m_Y;

        public Vector2Int(int x, int y)
        {
            m_X = x;
            m_Y = y;
        }

        // Set x and y components of an existing Vector.
        public void Set(int x, int y)
        {
            m_X = x;
            m_Y = y;
        }

        // Access the /x/ or /y/ component using [0] or [1] respectively.
        public int this[int index]
        {
            get
            {
                switch (index)
                {
                    case 0: return x;
                    case 1: return y;
                    default:
                        throw new IndexOutOfRangeException(String.Format("Invalid Vector2Int index addressed: {0}!", index));
                }
            }

            
            set
            {
                switch (index)
                {
                    case 0: x = value; break;
                    case 1: y = value; break;
                    default:
                        throw new IndexOutOfRangeException(String.Format("Invalid Vector2Int index addressed: {0}!", index));
                }
            }
        }

        // Returns the length of this vector (RO).
        public float magnitude {  get { return MathF.Sqrt((float)(x * x + y * y)); } }

        // Returns the squared length of this vector (RO).
        public int sqrMagnitude {  get { return x * x + y * y; } }

        // Returns the distance between /a/ and /b/.
        
        public static float Distance(Vector2Int a, Vector2Int b)
        {
            float diff_x = a.x - b.x;
            float diff_y = a.y - b.y;

            return (float)Math.Sqrt(diff_x * diff_x + diff_y * diff_y);
        }

        // Multiplies two vectors component-wise.
        
        public static Vector2Int Scale(Vector2Int a, Vector2Int b) { return new Vector2Int(a.x * b.x, a.y * b.y); }

        // Multiplies every component of this vector by the same component of /scale/.
        
        public void Scale(Vector2Int scale) { x *= scale.x; y *= scale.y; }

        
        public void Clamp(Vector2Int min, Vector2Int max)
        {
            x = Math.Max(min.x, x);
            x = Math.Min(max.x, x);
            y = Math.Max(min.y, y);
            y = Math.Min(max.y, y);
        }

        
        public static Vector2Int operator -(Vector2Int v)
        {
            return new Vector2Int(-v.x, -v.y);
        }

        
        public static Vector2Int operator +(Vector2Int a, Vector2Int b)
        {
            return new Vector2Int(a.x + b.x, a.y + b.y);
        }

        
        public static Vector2Int operator -(Vector2Int a, Vector2Int b)
        {
            return new Vector2Int(a.x - b.x, a.y - b.y);
        }
        
        public static Vector2 operator +(Vector2 a, Vector2Int b)
        {
            return new Vector2(a.X + b.x, a.Y + b.y);
        }

        
        public static Vector2 operator -(Vector2 a, Vector2Int b)
        {
            return new Vector2(a.X - b.x, a.Y - b.y);
        }
        
        public static Vector2 operator +(Vector2Int a, Vector2 b)
        {
            return new Vector2(a.x + b.X, a.y + b.Y);
        }

        
        public static Vector2 operator -(Vector2Int a, Vector2 b)
        {
            return new Vector2(a.x - b.X, a.y - b.Y);
        }

        
        public static Vector2Int operator *(Vector2Int a, Vector2Int b)
        {
            return new Vector2Int(a.x * b.x, a.y * b.y);
        }

        
        public static Vector2Int operator *(int a, Vector2Int b)
        {
            return new Vector2Int(a * b.x, a * b.y);
        }

        
        public static Vector2Int operator *(Vector2Int a, int b)
        {
            return new Vector2Int(a.x * b, a.y * b);
        }

        public static Vector2 operator *(float a, Vector2Int b)
        {
            return new Vector2(a * b.x, a * b.y);
        }

        
        public static Vector2 operator *(Vector2Int a, float b)
        {
            return new Vector2(a.x * b, a.y * b);
        }

        
        public static Vector2Int operator /(Vector2Int a, int b)
        {
            return new Vector2Int(a.x / b, a.y / b);
        }

        
        public static bool operator ==(Vector2Int lhs, Vector2Int rhs)
        {
            return lhs.x == rhs.x && lhs.y == rhs.y;
        }

        
        public static bool operator !=(Vector2Int lhs, Vector2Int rhs)
        {
            return !(lhs == rhs);
        }

        
        public override bool Equals(object other)
        {
            if (!(other is Vector2Int)) return false;

            return Equals((Vector2Int)other);
        }

        
        public bool Equals(Vector2Int other)
        {
            return x == other.x && y == other.y;
        }

        
        public override int GetHashCode()
        {
            const int p1 = 73856093;
            const int p2 = 83492791;
            return (x * p1) ^ (y * p2);
        }

        public static Vector2Int zero {  get { return s_Zero; } }
        public static Vector2Int one {  get { return s_One; } }
        public static Vector2Int ArrayUp {  get { return s_Up; } }
        public static Vector2Int ArrayDown {  get { return s_Down; } }
        public static Vector2Int left {  get { return s_Left; } }
        public static Vector2Int right {  get { return s_Right; } }

        private static readonly Vector2Int s_Zero = new Vector2Int(0, 0);
        private static readonly Vector2Int s_One = new Vector2Int(1, 1);
        private static readonly Vector2Int s_Up = new Vector2Int(0, -1);
        private static readonly Vector2Int s_Down = new Vector2Int(0, 1);
        private static readonly Vector2Int s_Left = new Vector2Int(-1, 0);
        private static readonly Vector2Int s_Right = new Vector2Int(1, 0);
    }
}
