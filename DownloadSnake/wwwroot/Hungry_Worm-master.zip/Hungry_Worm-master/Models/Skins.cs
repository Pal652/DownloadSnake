﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    public static class Skins
    {
        static List<Color[]> snakeColors;
        public static List<Color[]> SnakeColors
        {
            get
            {
                if (snakeColors == null) init();
                return snakeColors;
            }
        }
        static void init()
        {
            snakeColors = new List<Color[]>();
            snakeColors.Add(new Color[] { Color.Yellow, Color.Orange });
            snakeColors.Add(new Color[] { Color.Pink, Color.Purple });
            snakeColors.Add(new Color[] { Color.LightGreen, Color.DarkGreen });
            snakeColors.Add(new Color[] { Color.Magenta, Color.Red });
            snakeColors.Add(new Color[] { Color.LightBlue, Color.DarkBlue });
            snakeColors.Add(new Color[] { Color.SandyBrown, Color.Brown });
            snakeColors.Add(new Color[] { Color.Black, Color.White });
            snakeColors.Add(new Color[] { Color.Purple, Color.BlueViolet });
            snakeColors.Add(new Color[] { Color.GreenYellow, Color.Cyan });
            snakeColors.Add(new Color[] { Color.LightGoldenrodYellow, Color.Firebrick });
        }
    }
}
