﻿using Models.descendants;
using Models.descendants.ByModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    public static class ModelTiles
    {
        // double state : [inactive gravitable, active not] => invalid


        static Dictionary<string, StaticTileData> _prefabs;
        public static Dictionary<string, StaticTileData> prefabs
        {
            get
            {
                if (_prefabs == null) init();
                return _prefabs;
            }
        }

        internal static Dictionary<string, StaticTileData> _states = new Dictionary<string, StaticTileData>();

        static void init()
        {
            _prefabs = new Dictionary<string, StaticTileData>();
            _prefabs.Add("Brick", new StaticTileData("Brick", new string[1] { "brick.png" }));
            _prefabs.Add("Goal", new StaticTileData("Goal", new string[1] { "Goal.png" }, snakeCanClimbInto: true));
            _prefabs.Add("Stone", new StaticTileData("Stone", new string[1] { "Stone.png" }, pushable: true, gravitable: true));
            _prefabs.Add("Apple", new StaticTileData("Apple", new string[1] { "Apple.png" }, eatable: true));
            _prefabs.Add("BlackApple", new StaticTileData("BlackApple", new string[1] { "black_apple.png" }, eatable: true));
            _prefabs.Add("Shuriken", new StaticTileData("Shuriken", new string[1] { "Shuriken.png" }, kills: true));
            _prefabs.Add("Spike", new StaticTileData("Spike", new string[1] { "spike.png" }, new string[1] { "SpikeForground.png" }, kills: true, canFallTroughID: new string[1] { "Stone" }, CanBePushedIntoThis: new string[1] { "Stone" }));
            _prefabs.Add("SnakeHead", new ColoredStaticTileData("SnakeHead", new string[1] { "SnakeHeadC.png" }, new string[1] { "SHC.png" }, new string[1] { "SnakeHead.png" }, new string[1] { "SHB.png" }, pushable: true, gravitable: true));
            _prefabs.Add("SnakeBody", new ColoredStaticTileData("SnakeBody", new string[1] { "SnakeBodyC.png" }, new string[1] { "SBC.png" }, new string[1] { "SnakeBody.png" }, new string[1] { "SBB.png" }, controllable:true ));
            
            //_prefabs.Add("ColoredBrick", new ColoredStaticTileData("ColoredBrick", new string[1] { "SnakeBodyC.png" }, new string[1] { "SBC.png" }, new string[1] { "SnakeBody.png" }, new string[1] { "SBB.png" }));
            //_prefabs.Add("ColoredApple", new ColoredStaticTileData("Apple", new string[1] { "SnakeBodyC.png" }, new string[1] { "SBC.png" }, new string[1] { "SnakeBody.png" }, new string[1] { "SBB.png" }, eatable:true ));
            //_prefabs.Add("ColoredStone", new ColoredStaticTileData("ColoredStone", new string[1] { "SnakeBodyC.png" }, new string[1] { "SBC.png" }, new string[1] { "SnakeBody.png" }, new string[1] { "SBB.png" }, pushable:true, gravitable:true));
            
            //_prefabs.Add("FlyingStone", new StaticTileData("Stone", new string[1] { "Stone.png" }, pushable: true));
            //_prefabs.Add("FlyingStone", new DoubleStateData("Stone", new string[1] { "Stone.png" },));

        }
    }
}
