﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Hungry_Worm.Interfaces;
using Logic;
using Models;
using Models.imported;
using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Printing;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Hungry_Worm.ViewModels
{   
    public class LevelEditorViewModel : ObservableRecipient
    {
        public IEditor Editor { get; set; }
        public List<Label> Labels { get; set; } = new List<Label>();
        private Label selectedItem;
        public Label SelectedItem
        {
            get { return selectedItem; }
            set
            {
                SetProperty(ref selectedItem, value);
            }
        }        
        private string levelnumber;
        public string LevelNumber
        {
            get { return levelnumber; }
            set 
            { 
                levelnumber = value;
            }
        }

        public LevelEditorViewModel()
        {
            foreach (var item in ModelTiles.prefabs)
            {
                Label label = new Label();
                label.FontSize = 25;
                label.Foreground = Brushes.White;
                label.BorderBrush = Brushes.Black;
                label.Margin = new Thickness(2, 10, 2, 10);
                label.Content = item.Key;
                Labels.Add(label);
            }
            Label delete = new Label();
            delete.FontSize = 25;
            delete.Foreground = Brushes.White;
            delete.BorderBrush = Brushes.Black;
            delete.Margin = new Thickness(2, 10, 2, 10);
            delete.Content = "Delete";
            Labels.Add(delete);
        }      
        public void LoadMap()
        {
            if (LevelNumber != null)
            {
                ;
                SaveLoadSystemLogic.LoadLevel(LevelNumber);
                Editor.Mirror();
                LevelNumber = null;
            }           
        }
        public bool SaveMap()
        {
            //int playerCount = Editor.Players(); //working
            return SaveLoadSystemLogic.SaveLevel();      
        }
        public void PlaceBlock(int row, int col)
        {
            ;
            if (SelectedItem != null)
            {             
                Editor.Nullify(row, col);
                SaveLoadSystemLogic.LevelChangedAfterSuccesfulTry();

                if (SelectedItem.Content.ToString() == "Delete")
                {
                    return;
                }

                bool placement = false;

                Image im = new Image();
                im.Width = 50;
                im.Height = 50;
                im.Stretch = Stretch.Fill;
                im.Margin = new Thickness(0);
                im.Tag = selectedItem.Content;
                Grid.SetColumn(im, col);
                Grid.SetRow(im, row);

                switch ((selectedItem as Label).Content)
                {
                    case "SnakeHead":
                        placement = LevelEditorLogic.PlaceSnake(new Vector2Int(col, row),true);
                        switch (placement)
                        {
                            case true:
                                im.Source = new BitmapImage(ModelTiles.prefabs[(string)selectedItem.Content].ImagePathsBackGround[0]);
                                Editor.AddToGrid(im);
                                break;
                            default:
                                break;
                        }                       
                        break;
                    case "SnakeBody":
                        placement = LevelEditorLogic.PlaceSnake(new Vector2Int(col, row), false);
                        switch (placement)
                        {
                            case true:
                                im.Source = new BitmapImage(ModelTiles.prefabs[(string)selectedItem.Content].ImagePathsBackGround[0]);
                                Editor.AddToGrid(im);
                                break;
                            default:
                                break;
                        }
                        break;
                    default:
                        LevelEditorLogic.PlaceBlock(new Vector2Int(col, row), SelectedItem.Content.ToString(), null);
                        im.Source = new BitmapImage(ModelTiles.prefabs[(string)selectedItem.Content].ImagePathsBackGround[0]);
                        Editor.AddToGrid(im);
                        break;
                }                       
            }
        }
        public void PlaceBlockPre(int row, int col, string block)
        {
            ;
            Editor.Nullify(row, col);

            Image im = new Image();
            im.Width = 50;
            im.Height = 50;
            im.Stretch = Stretch.Fill;
            im.Margin = new Thickness(0);
            im.Tag = block;
            Grid.SetColumn(im, col);
            Grid.SetRow(im, row);

            im.Source = new BitmapImage(ModelTiles.prefabs[block].ImagePathsBackGround[0]);
            Editor.AddToGrid(im);
            
            
        }
    }
}
