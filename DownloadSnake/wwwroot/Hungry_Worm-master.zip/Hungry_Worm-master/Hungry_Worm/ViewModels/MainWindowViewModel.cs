﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Logic;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Xml.Serialization;
using static Logic.LevelSelectorLogic;

namespace Hungry_Worm.ViewModels
{
    public class MainWindowViewModel : ObservableRecipient
    {
        private ObservableCollection<Nested> _stages;
        public ObservableCollection<Nested> Stages
        {
            get => _stages;
            set { SetProperty(ref _stages, value); OnPropertyChanged(nameof(Stages)); }
        }
        //public ObservableCollection<Nested> stages { get; set; }
        public int SelectedPlayer {  get; set; }   
        public Nested SelectedLevel {  get; set; }   
        public MainWindowViewModel()
        {
            string dir = Path.GetFullPath(Path.Combine(Directory.GetCurrentDirectory(), "../../../../Hungry_Worm/Resources/Images/IndexImages/"));
            string file = "Basic.jpg";
            var uri = new Uri(dir + file);
            var AbsoluteUri = "file:///C:/Users/palse/source/repos/Hungry_Worm2/Hungry_Worm/Resources/Images/IndexImages/Basic.png";

            Stages = new ObservableCollection<Nested>();
            //{
            //    new Nested(new Uri(AbsoluteUri), 2, 30, 33, false, "level", true, true),
            //    new Nested(new Uri(AbsoluteUri), 2, 30, 33, false, "level", false, false),
            //    new Nested(new Uri(AbsoluteUri), 2, 30, 33, false, "level", false, true),
            //    new Nested(new Uri(AbsoluteUri), 2, 30, 33, false, "level", false, true)
            //};

        }
        public void LoadStages(int Player)
        {
            Stages.Clear();
            foreach (var item in GetSelectorLevels(Player, "save"))
            {
                Stages.Add(item);
            }      
        }
    }

}
