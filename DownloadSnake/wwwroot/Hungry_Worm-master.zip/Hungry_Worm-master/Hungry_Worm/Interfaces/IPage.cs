﻿using Hungry_Worm.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hungry_Worm.Interfaces
{
    internal interface IPage
    {
        public MainWindowViewModel mainModel { get; set; }
    }
}
