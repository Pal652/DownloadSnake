﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Hungry_Worm.Interfaces
{
    public interface IEditor
    {
        void AddToGrid(object obj);
        void Nullify(int row, int col);
        int Players();
        void Mirror();
    }
}
