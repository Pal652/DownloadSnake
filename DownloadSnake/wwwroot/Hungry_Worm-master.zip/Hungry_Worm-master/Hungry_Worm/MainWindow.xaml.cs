﻿using Hungry_Worm.Pages;
using Hungry_Worm.ViewModels;
using Logic;
using Models.imported;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using static System.Runtime.CompilerServices.RuntimeHelpers;

namespace Hungry_Worm
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static Frame MainFrame { get; set; }
        MediaPlayer CurrentMusic { get; set; }
        string filePath = Directory.GetParent(Directory.GetParent(Directory.GetParent(System.IO.Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory)).FullName).FullName).FullName;
        public enum pages
        {
            game,editor,mainMenu,play
        }

        public static Page[] Pages = new Page[]
        {
            new GamePage(),
            new LevelEditorPage(),
            new MainMenuPage(),
            new PlayPage(),
        };

        public static void SetPage(pages page)
        {
            if (page == pages.editor)
            {
                SaveLoadSystemLogic.OnEditorLoad();
                ((LevelEditorPage)Pages[(int)page]).Mirror();
            }
            MainFrame.Content = Pages[(int)page];
            if (page == pages.game) Display._instance.InvalidateVisual();
        }

        public static bool TryMode;

        public MainWindow()
        {
            InitializeComponent();
            SaveLoadSystemLogic.Start();
            MainFrame = Frame;
            SetPage(pages.mainMenu);

            CurrentMusic = new MediaPlayer();
            CurrentMusic.Volume = 0.3;
            CurrentMusic.MediaEnded += new EventHandler(LoopMusic);
            ChangeMusic("future 2B");
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            

            if (e.Key == Key.Escape && MainFrame.Content.GetType() == typeof(GamePage))
            {
                SetPage(pages.mainMenu);
            }
            if (MainFrame.Content.GetType() == typeof(GamePage) && GameLogic.FrameUpdate(0)) //key only active in GamePage
            {
                try
                {
                    switch (e.Key)
                    {
                        case Key.W: //WASD player 1
                            GameLogic.Move(Vector2Int.ArrayUp, 0);
                            break;
                        case Key.A:
                            GameLogic.Move(Vector2Int.left, 0);
                            break;
                        case Key.S:
                            GameLogic.Move(Vector2Int.ArrayDown, 0);
                            break;
                        case Key.D:
                            GameLogic.Move(Vector2Int.right, 0);
                            break;

                        case Key.Up: //ARROWS player 2
                            GameLogic.Move(Vector2Int.ArrayUp, 1);
                            break;
                        case Key.Left:
                            GameLogic.Move(Vector2Int.left, 1);
                            break;
                        case Key.Down:
                            GameLogic.Move(Vector2Int.ArrayDown, 1);
                            break;
                        case Key.Right:
                            GameLogic.Move(Vector2Int.right, 1);
                            break;

                        case Key.G: //FGTH player 3
                            GameLogic.Move(Vector2Int.left, 2);
                            break;
                        case Key.H:
                            GameLogic.Move(Vector2Int.ArrayDown, 2);
                            break;
                        case Key.Z:
                            GameLogic.Move(Vector2Int.ArrayUp, 2);
                            break;
                        case Key.J:
                            GameLogic.Move(Vector2Int.right, 2);
                            break;

                        case Key.NumPad4: //JKIL player 4
                            GameLogic.Move(Vector2Int.left, 3);
                            break;
                        case Key.NumPad5:
                            GameLogic.Move(Vector2Int.ArrayDown, 3);
                            break;
                        case Key.NumPad6:
                            GameLogic.Move(Vector2Int.right, 3);
                            break;
                        case Key.NumPad8:
                            GameLogic.Move(Vector2Int.ArrayUp, 3);
                            break;
                        default:
                            break;
                    }
                }
                catch (Exception) { } // invalid key
                
            }
        }
        public void ChangeMusic(string Music)
        {
            CurrentMusic.Open(new Uri(filePath + @"/Resources/OST/" + Music + ".mp3"));
            
            CurrentMusic.Play();
        }
        private void LoopMusic(object sender, EventArgs e)
        {
            CurrentMusic.Position = TimeSpan.Zero;
            CurrentMusic.Play();
        }
    }
}
