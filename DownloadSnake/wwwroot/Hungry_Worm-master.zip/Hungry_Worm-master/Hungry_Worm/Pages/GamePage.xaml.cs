﻿using Logic;
using Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using static Hungry_Worm.MainWindow;
using static System.Runtime.CompilerServices.RuntimeHelpers;

namespace Hungry_Worm.Pages
{
    /// <summary>
    /// Interaction logic for GamePage.xaml
    /// </summary>
    public partial class GamePage : Page
    {

        float refreshRate = 0.05f;

        public static bool TryMode
        {
            get
            {
                return MainWindow.TryMode;
            }
        }

        public static bool firstInit = true;

        public static DispatcherTimer dt = new DispatcherTimer();

        public bool frameEnd;
        public GamePage()
        {
            InitializeComponent();

            

            
            dt.Interval = TimeSpan.FromSeconds(refreshRate);
            dt.Tick += Dt_Tick;
            dt.Start();
            GameLogic.SetupSpeeds(4.5f, 5, 5, 4);
        }

        public void Dt_Tick(object? sender, EventArgs e)
        {
            if (MainFrame.Content.GetType() == typeof(GamePage))
            {
                frameEnd = GameLogic.FrameUpdate(refreshRate);
                if (frameEnd == false)
                {
                    display.InvalidateVisual();
                }
                if (GameLogic.DoesGameEnds(out bool win))
                {
                    if (win)
                    {
                        if (TryMode) SaveLoadSystemLogic.EditorTryWon();
                        else SaveLoadSystemLogic.GameWonUpdateSave();
                    }
                    if (TryMode) MainWindow.SetPage(pages.editor);
                    else MainWindow.SetPage(pages.play);

                    if (TryMode) CurrectLevelData.LoadLevel("../inEdit");
                    //dt.Tick -= Dt_Tick;
                }
            }
            
        }

        private void Page_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            display.Resize(gameGrid.ActualWidth,gameGrid.ActualHeight);
        }
    }
}
