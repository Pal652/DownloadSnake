﻿using Hungry_Worm.Interfaces;
using Hungry_Worm.Pages;
using Hungry_Worm.ViewModels;
using Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static Logic.LevelSelectorLogic;

namespace Hungry_Worm
{
    /// <summary>
    /// Interaction logic for PlayPage.xaml
    /// </summary>
    public partial class PlayPage : Page, IPage
    {
        public MainWindowViewModel mainModel {  get; set; }
        public PlayPage()
        {
            InitializeComponent();
            mainModel = new MainWindowViewModel();
        }

        private void Button_Back(object sender, RoutedEventArgs e)
        {
            MainWindow.SetPage(MainWindow.pages.mainMenu);
        }

        private void Button_Play(object sender, MouseButtonEventArgs e)
        {
            if (StageList.SelectedItem != null)
            {
                //logic game start
                MainWindow.TryMode = false;
                int maxSteps = (int)(2.4f * (StageList.SelectedItem as Nested).MinSeps);
                GameLogic.Init(maxSteps);
                SaveLoadSystemLogic.LoadLevel((StageList.SelectedItem as Nested).LevelName);
                MainWindow.SetPage(MainWindow.pages.game);
            }

        }
        private void slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (mainModel != null)
            {
                mainModel.LoadStages((int)slider.Value);
                StageList.ItemsSource = new List<Object>();
                StageList.ItemsSource = mainModel.Stages;
            }            
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            if (mainModel != null)
            {
                mainModel.LoadStages((int)slider.Value);
                StageList.ItemsSource = new List<Object>();
                StageList.ItemsSource = mainModel.Stages;
            }
        }
    }
}
