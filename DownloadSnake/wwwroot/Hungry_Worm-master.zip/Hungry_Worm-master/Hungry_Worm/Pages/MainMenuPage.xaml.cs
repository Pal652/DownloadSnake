﻿using Hungry_Worm.ViewModels;
using Logic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Hungry_Worm
{
    /// <summary>
    /// Interaction logic for MainMenuPage.xaml
    /// </summary>
    public partial class MainMenuPage : Page
    {
        public MainMenuPage()
        {
            InitializeComponent();          
        }

        private void PlayLabel(object sender, MouseButtonEventArgs e)
        {
            MainWindow.SetPage(MainWindow.pages.play);
        }
        private void LevelLabel(object sender, MouseButtonEventArgs e)
        {
            MainWindow.SetPage(MainWindow.pages.editor);
            SaveLoadSystemLogic.LoadEditor();
        }

        private void ExitLabel(object sender, MouseButtonEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
