﻿using Hungry_Worm.Interfaces;
using Hungry_Worm.Pages;
using Hungry_Worm.ViewModels;
using Logic;
using Models;
using Newtonsoft.Json;
using Repository;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hungry_Worm
{
    /// <summary>
    /// Interaction logic for LevelEditorPage.xaml
    /// </summary>
    public partial class LevelEditorPage : Page, IEditor
    {
        private List<GridTemplate> GridContent = new List<GridTemplate>();

        private string _filePath = System.IO.Path.GetDirectoryName(System.AppDomain.CurrentDomain.BaseDirectory);

        LevelEditorViewModel viewModel;
        public LevelEditorPage()
        {
            InitializeComponent();
            viewModel = new LevelEditorViewModel();
            viewModel.Editor = this as IEditor;

            /*
            _filePath = Directory.GetParent(Directory.GetParent(Directory.GetParent(_filePath).FullName).FullName).FullName;
            _filePath += @"\Resources\GridContent.json";
            string json = File.ReadAllText(_filePath);
            GridContent = JsonConvert.DeserializeObject<List<GridTemplate>>(json);
            */

            //if (GridContent != null )
            //{
            //    foreach (GridTemplate item in GridContent)
            //    {
            //        viewModel.PlaceBlockPre(item.Row,item.Column,item.ModelID);
            //    }
            //}
            
        }

        private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
        {
            var point = Mouse.GetPosition(myGrid);
            int row = 0;
            int col = 0;
            double accumulatedHeight = 0.0;
            double accumulatedWidth = 0.0;

            // calc row mouse was over
            foreach (var rowDefinition in myGrid.RowDefinitions)
            {
                accumulatedHeight += rowDefinition.ActualHeight;
                if (accumulatedHeight >= point.Y)
                    break;
                row++;
            }

            // calc col mouse was over
            foreach (var columnDefinition in myGrid.ColumnDefinitions)
            {
                accumulatedWidth += columnDefinition.ActualWidth;
                if (accumulatedWidth >= point.X)
                    break;
                col++;
            }
            viewModel.PlaceBlock(row, col);          
        }

        private void Blocks_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (Blocks.SelectedItem != null)
            {
                viewModel.SelectedItem = (Blocks.SelectedItem as Label);
            }
        }

        public void AddToGrid(object obj)
        {
            if (obj is Image)
            {
                myGrid.Children.Add(obj as Image);
            }
            else
            {
                myGrid.Children.Add(obj as Label);
            }
            //SaveLoadSystemLogic.LevelChangedAfterSuccesfulTry();
        }

        public void Nullify(int row, int col)
        {
            for (int i = myGrid.Children.Count-1; i >= 0; i--)
            {
                UIElement item = myGrid.Children[i];
                if (Grid.GetColumn(item) == col && Grid.GetRow(item) == row)
                {
                    if (LevelEditorLogic.RemoveBlock(col, row)) // not snake
                    {
                        myGrid.Children.Remove(item);
                    }
                    //break;
                }
            }
        }

        public int Players() //how many snakeheads on grid = how many players
        {
            int players = 0;

            foreach (UIElement item in myGrid.Children)
            {
                if (item.GetType() == typeof(Label) && (item as Label).Content.ToString() == "SnakeHead")
                {
                    players++;
                }
            }
            return players;
        }
        public void Mirror()
        {
            ;
            myGrid.Children.Clear();
            for (int width = 0; width < CurrectLevelData.Data.Map.GetLength(0); width++)
            {
                for (int height = 0; height < CurrectLevelData.Data.Map.GetLength(1); height++)
                {
                    if (CurrectLevelData.Data.Map[width, height].Count != 0) 
                    {
                        viewModel.PlaceBlockPre(height, width, CurrectLevelData.Data.Map[width, height].First().ModelID);
                    }
                }
            }
        }
        #region Buttons
        private void Button_Back(object sender, MouseButtonEventArgs e)
        {
            //save current grid into json
            /*
            GridContent = new List<GridTemplate>();
            foreach (UIElement item in myGrid.Children)
            {
                ;
                GridContent.Add(new GridTemplate(Grid.GetRow(item),Grid.GetColumn(item),(item as Image).Tag.ToString()));
            }
            string? json = JsonConvert.SerializeObject(GridContent,Formatting.Indented);
            File.WriteAllText(_filePath,json);
            //

            */

            MainWindow.SetPage(MainWindow.pages.mainMenu);
        }
        private void Button_Import(object sender, MouseButtonEventArgs e)
        {
            ;
            levelStack.Visibility = Visibility.Visible;
            selectorStack.Visibility = Visibility.Hidden;
            viewModel.LoadMap();
        }

        private void Button_Try(object sender, MouseButtonEventArgs e)
        {
            /*
            //save current grid into json
            GridContent = new List<GridTemplate>();
            foreach (UIElement item in myGrid.Children)
            {
                GridContent.Add(new GridTemplate(Grid.GetRow(item), Grid.GetColumn(item), (item as Image).Tag.ToString()));
            }
            string? json = JsonConvert.SerializeObject(GridContent, Formatting.Indented);
            File.WriteAllText(_filePath, json);
            //
            */
            SaveLoadSystemLogic.TryStarted();
            GameLogic.Init(int.MaxValue);
            MainWindow.TryMode = true;
            MainWindow.SetPage(MainWindow.pages.game);

        }

        private void Button_Save(object sender, MouseButtonEventArgs e)
        {
            ;
            if (viewModel.SaveMap()) // succes
            {
                levelStack.Visibility = Visibility.Hidden;
                selectorStack.Visibility = Visibility.Visible;
                saveLabel.Content = "Save Successful";
                myGrid.Children.Clear();
            }
            else
            {
                levelStack.Visibility = Visibility.Hidden;
                selectorStack.Visibility = Visibility.Visible;
                saveLabel.Content = "You shold complete the level first";
                myGrid.Children.Clear();
            }
            
        }
        private void LevelBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            viewModel.LevelNumber = LevelBox.Text;
        }
        private void WIPE(object sender, MouseButtonEventArgs e)
        {
            LevelEditorLogic.Wipe();
            //foreach (UIElement item in myGrid.Children)
            //{
            //    try
            //    {
            //        LevelEditorLogic.RemoveBlock(Grid.GetColumn(item), Grid.GetRow(item));
            //    }
            //    catch (Exception)
            //    {
                    
            //    }
            //}
            myGrid.Children.Clear();
        }
        #endregion

    }
    public class GridTemplate
    {
        public GridTemplate(int row, int column, string modelID)
        {
            Row = row;
            Column = column;
            ModelID = modelID;
        }
        public int Row { get; set; }
        public int Column { get; set; }
        public string ModelID { get; set; }
    }
}
