﻿using Logic;
using Models;
using Models.descendants.ByInstance;
using Models.descendants.ByModel;
using System;
using System.Drawing;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using Logic.GameLogics;

namespace Hungry_Worm
{
    public class Display : FrameworkElement
    {
        private double areaWidth;
        private double areaHeight;
        public static List<InstanceTileData> Tiles { get; set; } = new List<InstanceTileData>();


        //private static readonly Lazy<Display> lazy = new Lazy<Display>(() => new Display());
        //public static Display Instance => lazy.Value;

        ImageBrush sun = new ImageBrush(new BitmapImage(new Uri("pack://application:,,,/Resources/sun.png")));
        ImageBrush moon = new ImageBrush(new BitmapImage(new Uri("pack://application:,,,/Resources/moon.png")));

        ImageBrush[] Bbacks = new ImageBrush[]
        {
            new ImageBrush(new BitmapImage(new Uri("pack://application:,,,/Resources/Bback1.png"))),
            new ImageBrush(new BitmapImage(new Uri("pack://application:,,,/Resources/Bback2.png"))),
            new ImageBrush(new BitmapImage(new Uri("pack://application:,,,/Resources/Bback3.png"))),
            new ImageBrush(new BitmapImage(new Uri("pack://application:,,,/Resources/Bback4.png"))),
            new ImageBrush(new BitmapImage(new Uri("pack://application:,,,/Resources/Bback5.png")))
        };

        ImageBrush[] Fbacks = new ImageBrush[]
        {
            new ImageBrush(new BitmapImage(new Uri("pack://application:,,,/Resources/Fback1.png"))),
            new ImageBrush(new BitmapImage(new Uri("pack://application:,,,/Resources/Fback2.png"))),
            new ImageBrush(new BitmapImage(new Uri("pack://application:,,,/Resources/Fback3.png"))),
            new ImageBrush(new BitmapImage(new Uri("pack://application:,,,/Resources/Fback4.png"))),
            new ImageBrush(new BitmapImage(new Uri("pack://application:,,,/Resources/Fback5.png")))
        };

        int backgrondNum
        {
            get => LogicVariables.Seed % Fbacks.Length;
        }

        public static Display _instance;

        public Display()
        {
            if (_instance == null) _instance = this;
        }
        public void Resize(double areaWidth, double areaHeight)
        {
            this.areaWidth = areaWidth;
            this.areaHeight = areaHeight;
            this.InvalidateVisual(); // calls OnRender
            //if(!LoopOn) GameLoop(true);
        }

        Random rnd = new Random();

        protected override void OnRender(DrawingContext drawingContext)
        {
            base.OnRender(drawingContext);

            Tiles = GameLogic.DrawobjectsInDrawOrder();

            double cellWidth = this.areaWidth / 30;
            double cellHeight = this.areaHeight / 20;

            /*
            for (int width = 0; width < 30; width++)
            {
                for (int height = 0; height < 20; height++)
                {
                    drawingContext.DrawEllipse(Brushes.AntiqueWhite, new Pen(), new Point(width*cellWidth+cellWidth/2, height*cellHeight+cellHeight/2), rnd.Next(15, 25), rnd.Next(15,25));
                }
            }
            */

            base.OnRender(drawingContext);




            







            DrawBackground(drawingContext);

            drawTiles(drawingContext);
        }

        private void DrawBackground(DrawingContext drawingContext)
        {
            //for (int x = (int)(areaWidth * (-0.1)); x < areaWidth * (0.9); x += (int)(areaWidth / 30))
            //{
            //    drawingContext.DrawEllipse(sun, new Pen(), new System.Windows.Point(areaWidth * (0.9) - x, (0.00058 * x * x) + areaHeight / 6), 50, 50);
            //}

            drawingContext.DrawRectangle(Bbacks[backgrondNum], new Pen(), new System.Windows.Rect(0,0,areaWidth,areaHeight));

            
            if (LogicVariables.Steps  < (LogicVariables.MaxSteps/2))
            {
                int _step = (int)((LogicVariables.Steps / (float)LogicVariables.MaxSteps) * 60);
                int X = (int)(areaWidth * (-0.1) + _step * (areaWidth / 30));
                drawingContext.DrawEllipse(sun, new Pen(), new System.Windows.Point(areaWidth * (0.9) - X, (0.00058 * X * X) + areaHeight / 6), 75, 75);
            }
            else
            {
                int _step = (int)(((LogicVariables.Steps - (LogicVariables.MaxSteps/2)) / (float)LogicVariables.MaxSteps) * 60);
                int X = (int)(areaWidth * (-0.1) + (_step) * (areaWidth / 30));
                drawingContext.DrawEllipse(moon, new Pen(), new System.Windows.Point(areaWidth * (0.9) - X, (0.00058 * X * X) + areaHeight / 6), 75, 75);
            }

            drawingContext.DrawRectangle(Fbacks[backgrondNum], new Pen(), new System.Windows.Rect(0, 0, areaWidth, areaHeight));


        }

        void drawTiles(DrawingContext drawingContext)
        {
            if (areaWidth != 0 && areaHeight != 0)
            {
                double cellWidth = areaWidth / 30;
                double cellHeight = areaHeight / 20;

                foreach (InstanceTileData tile in Tiles) // background draw
                {
                    //Rect recta = new Rect(double x, double y, double width, double height);

                    ImageBrush brush = new ImageBrush();

                    ;
                    var item = ModelTiles.prefabs[tile.ModelID];
                    Rect rect = new Rect(tile.PosXY.X * cellWidth, tile.PosXY.Y * cellHeight, 78, 62);

                    if (item is ColoredStaticTileData)
                    {
                        ColoredStaticTileData C_item = (ColoredStaticTileData)item;

                        // draw background

                        ImageBrush b2 = new ImageBrush();
                        b2.ImageSource = new BitmapImage(C_item.AbsoluteBackgroundP[0]);
                        drawingContext.DrawRectangle(b2, new Pen(), rect);


                        // draw color




                        System.Drawing.Color c = (Skins.SnakeColors[((ColoredInstanceTileData)tile).OwnerNum][((ColoredInstanceTileData)tile).modifier]);
                        System.Windows.Media.Color c2 = System.Windows.Media.Color.FromArgb(c.A, c.R, c.G, c.B);
                        SolidColorBrush contentBrush = new SolidColorBrush(c2);

                        // Load the image to be used as an opacity mask
                        BitmapImage maskImage = new BitmapImage(C_item.ColorableImagePaths[0]);
                        ImageBrush maskBrush = new ImageBrush(maskImage);


                        // Create a DrawingGroup to apply the opacity mask
                        DrawingGroup dg = new DrawingGroup();
                        using (DrawingContext dc = dg.Open())
                        {
                            
                            dc.DrawRectangle(contentBrush, null, rect);  // Draw your rectangle with the content brush
                        }
                        dg.OpacityMask = maskBrush;
                        drawingContext.DrawDrawing(dg);

                        
                        // draw lines

                        brush.ImageSource = new BitmapImage(C_item.LinesImagePaths[0]);
                        drawingContext.DrawRectangle(brush, new Pen(), rect);
                    }
                    else
                    {
                        brush.ImageSource = new BitmapImage(new Uri(item.ImagePathsBackGround[0].ToString()));
                        drawingContext.DrawRectangle(brush, new Pen(), rect);
                    }

                }
                foreach (InstanceTileData tile in Tiles) // forground draw
                {
                    ImageBrush brush = new ImageBrush();


                    // colored ez még nem jó
                    //System.Windows.Shapes.Rectangle rc = new System.Windows.Shapes.Rectangle();
                    //rc.Fill = Brushes.Red;
                    //rc.OpacityMask = brush;

                    //drawingContext.DrawRectangle()
                    if (ModelTiles.prefabs[tile.ModelID].ImagePathsForground == null) continue;
                    brush.ImageSource = new BitmapImage(new Uri(ModelTiles.prefabs[tile.ModelID].ImagePathsForground[0].ToString()));
                    drawingContext.DrawRectangle(brush, new Pen(), new Rect(tile.PosXY.X * cellWidth, tile.PosXY.Y * cellHeight, 64, 54));
                }
            }           
        }
    }
}
