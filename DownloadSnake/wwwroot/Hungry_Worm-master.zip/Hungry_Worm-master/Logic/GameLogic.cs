﻿using Logic.GameLogics;
using Models;
using Models.descendants.ByInstance;
using Models.imported;
using Repository;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logic
{
    public static class GameLogic
    {

        static Random rnd = new Random();

        public static bool DoesGameEnds(out bool win)
        {
            win = LogicVariables.Win;
            return LogicVariables.GameEndsDeath || win;
        }

        public static void Init(int MaxSteps)
        {
            LogicVariables.MaxSteps = MaxSteps;
            LogicVariables.PlayerNum = CurrectLevelData.PlayerNum;
            LogicVariables.GameEndsDeath = false;
            LogicVariables.HeadPushHappened = false;
            LogicVariables.Steps = 0;
            LogicVariables.Seed = rnd.Next();
        }

        public static void SetupSpeeds(float MoveSpeed, float FallStarterVelocity, float FallAccel, float WinMoveSpeed)
        {
            MoveLogic.MoveSpeed = MoveSpeed;
            MoveLogic.WinMoveSpeed = WinMoveSpeed;
            FallLogic.FallAccel = FallAccel;
            FallLogic.FallStarterVelocity = FallStarterVelocity;
        }


        static void FallLogically() // 1 turn amount of fall (lot of fallOnce-s)
        {
            FallLogic.Allfix = false;
            while (!FallLogic.Allfix) // setup gravityData / [fallCount + (GotDestroyed)]
            {
                FallOnceLogic.FixCheckForAll();
                FallLogic.FallOnMapArray();
            }

            // make destroyed fall out of the map
            foreach (var l in CurrectLevelData.Data.Map)
            {
                foreach (var tile in l)
                {
                    if (!tile.StaticTileData.gravitable) continue;
                    if (tile.GravityData.GotDestroyed) tile.GravityData.fallCount = 30;
                }
            }
        }

        public static bool Move(Vector2Int direction, int controllingPlayer) // returns true, if move was finished
        {
            // logical move and logical fall


            //° Move
            IsMoveing = MoveLogic.MovePossible(direction, CurrectLevelData.GetHead(controllingPlayer));
            IsFalling = IsMoveing;
            if (IsMoveing) LogicVariables.Steps++;

            

            return IsMoveing;
        }

        static void StateChanger() // for doubleStates
        {
            foreach (var list in CurrectLevelData.Data.Map)
            {
                foreach (var item in list)
                {
                    if (item is InstanceTimyTileData t) t.SetActive(LogicVariables.Steps);
                }
            }
        }

        static int NTZ(int x) // negativeToZero
        {
            return (int)(x + MathF.Abs(x))/2;
        }

        public static List<InstanceTileData> DrawobjectsInDrawOrder()
        {
            var orderedDraws = new List<InstanceTileData>(50);
            var map = CurrectLevelData.Data.Map;
            int XMAX = map.GetLength(0) - 1;
            int YMAX = map.GetLength(1) - 1;

            for (int sumXY = (XMAX + YMAX); sumXY >= 0; sumXY--)
            {
                for (int X = NTZ(sumXY-YMAX); sumXY - X >= NTZ(sumXY - XMAX); X++)
                {
                    int Y = sumXY - X;
                    for (int i = map[X, Y].Count-1; i >= 0; i--)
                    {
                        if (map[X, Y][i].ModelID == "null") continue;
                        orderedDraws.Add(map[X, Y][i]);
                    }
                }
            }
            return orderedDraws;
        }


        static bool IsMoveing;
        static bool MoveingInPrevUpdate;
        static bool IsFalling;
        public static bool FrameUpdate(float DeltaTime) // returns true if everithing is still!
        {
            // UI move and UI fall (+ WinMove)

            if (IsMoveing)
            {
                MoveingInPrevUpdate = IsMoveing;
                IsMoveing = !MoveLogic.Move(DeltaTime);

                if (MoveingInPrevUpdate != IsMoveing)
                {
                    //° fall
                    FallLogically();
                }
            }
            else if (IsFalling)
            {
                IsFalling = FallLogic.Fall(DeltaTime);
                CurrectLevelData.Data.Map.GetLength(0);
                ;
            }
            else
            {
                //destroy gotDestroyed => deported into fallLogic

                //foreach (var l in CurrectLevelData.Data.Map)
                //{
                //    foreach (var item in l)
                //    {
                //        if (!item.StaticTileData.gravitable || !item.GravityData.GotDestroyed) continue;
                //        DestroyLogic.DestroyAnyObject(item);
                //        if (item is SnakeHead) LogicVariables.GameEndsDeath = true;
                //    }
                    
                //}
                StateChanger();

                if (LogicVariables.Steps > LogicVariables.MaxSteps) LogicVariables.GameEndsDeath = true;

                return true; // not moveing
            }

            return false;
        }
    }
}
