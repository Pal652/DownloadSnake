﻿using Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logic
{
    public static class LevelSelectorLogic
    {
        public class Nested
        {
            public Uri IndexImage { get; set; }
            public int Stars { get; set; }
            public int MinSeps { get; set; }
            public int? PlayerMinSeps { get; set; }
            public bool BunnyKilled { get; set; }
            public string LevelName { get; set; }
            public bool NoHeadPush { get; set; }
            public bool NoHeadPushPossible { get; set; }

            public bool s1V
            {
                get
                {
                    return Stars >= 1;
                }
            }
            public bool s2V
            {
                get
                {
                    return Stars >= 2;
                }
            }
            public bool s3V
            {
                get
                {
                    return Stars >= 3;
                }
            }
            public bool s1nV
            {
                get
                {
                    return Stars < 1;
                }
            }
            public bool s2nV
            {
                get
                {
                    return Stars < 2;
                }
            }
            public bool s3nV
            {
                get
                {
                    return Stars < 3;
                }
            }

            public Nested(Uri indexImage, int stars, int minseps, int? playerMinSeps, bool bunnyKilled, string levelName, bool noHeadPush, bool noHeadPushPossible)
            {
                IndexImage = indexImage;
                Stars = stars;
                MinSeps = minseps;
                PlayerMinSeps = playerMinSeps;
                BunnyKilled = bunnyKilled;
                LevelName = levelName;
                NoHeadPush = noHeadPush;
                NoHeadPushPossible = noHeadPushPossible;
            }
        }

        public static List<Nested> GetSelectorLevels(int playerNum, string SaveFile)
        {
            return LevelMetaData.Metas.Where(m => m.Value.PlayerNum == playerNum).Select(m => (m.Value.Data.ContainsKey(SaveFile))?
            new Nested(m.Value.IndexImage, m.Value.Data[SaveFile].StarsCollected, m.Value.MinimalSteps, m.Value.Data[SaveFile].PersonalMinimalSteps, m.Value.Data[SaveFile].BunnyKilled, m.Key, m.Value.Data[SaveFile].NoHeadPushAchievement, m.Value.NoHeadpush_Possible)
            :
            new Nested(m.Value.IndexImage, 0, m.Value.MinimalSteps, null, false, m.Key, false, m.Value.NoHeadpush_Possible)
            ).ToList();
        }

        public static List<string> GetSaves
        {
            get
            {
                return Saves.SaveNames;
            }
        }

        public static void AddSave(string SaveName)
        {
            if (Saves.SaveNames.Contains(SaveName)) return;
            Saves.SaveNames.Add(SaveName);
        }

    }
}
