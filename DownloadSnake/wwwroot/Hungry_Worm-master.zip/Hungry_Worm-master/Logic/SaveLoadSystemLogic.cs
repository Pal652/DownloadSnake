﻿using Logic.GameLogics;
using Newtonsoft.Json;
using Repository;
using System.Text.Json.Serialization;

namespace Logic
{
    public static class SaveLoadSystemLogic
    {
        public static List<LevelMetaData.Nested> CurrectSelectorMetas; // selectorLevels -> meta [index = place in selector]

        static LevelMetaData.Nested? InProgress;

        public static void Start() // on main menu firs loaded
        {
            LevelMetaData.Load();
            Saves.Load();
        }

        public static void ExitGame() // on main menu exit
        {
            LevelMetaData.Save();
            Saves.Save();
        }

        
        //public static void SaveChoosen(string SaveName) // game
        //{
        //    if (!Saves.SaveNames.Contains(SaveName)) throw new ArgumentException("Unknown Save");

        //    LogicVariables.SaveName = SaveName;
        //}

        public static void OnEditorLoad()
        {
            CurrectLevelData.LoadLevel("../inEdit");
        }

        public static void EditorTryWon() // you can only save if try completed (with win), and level not changed after
        {
            int s = LogicVariables.Steps;
            if (InProgress != null) // not first won in editor
            {
                InProgress.PlayerNum = Math.Min(LogicVariables.PlayerNum, InProgress.PlayerNum);
                InProgress.NoHeadpush_Possible |= !LogicVariables.HeadPushHappened;
                if (InProgress.MinimalSteps < s)
                {
                    InProgress.MinimalSteps = s;
                    InProgress.ThreeStarSteps = (int)(1.2 * s);
                    InProgress.TwoStarSteps = (int)(1.5 * s);
                    InProgress.OneStarSteps = (int)(2.1 * s);
                }
            }
            else // first won in editor
            {
                InProgress = new LevelMetaData.Nested();
                InProgress.PlayerNum = LogicVariables.PlayerNum;
                InProgress.MinimalSteps = s;
                InProgress.NoHeadpush_Possible = !LogicVariables.HeadPushHappened;
                InProgress.ThreeStarSteps = (int)(1.2 * s);
                InProgress.TwoStarSteps = (int)(1.5 * s);
                InProgress.OneStarSteps = (int)(2.1 * s);
            }
            CurrectLevelData.LoadLevel("../inEdit");
        }

        public static void GameWonUpdateSave() // NOT in editor
        {
            // handles save not created too

            var saves = LevelMetaData.Metas[LogicVariables.LevelName];
            if (!saves.Data.ContainsKey(LogicVariables.SaveName)) saves.Data[LogicVariables.SaveName] = new LevelMetaData.Nested.PlayTroughLevelData();
            var save = saves.Data[LogicVariables.SaveName];


            if (save.PersonalMinimalSteps == 0 || LogicVariables.Steps < save.PersonalMinimalSteps) // new record
            {
                if (saves.ThreeStarSteps >= LogicVariables.Steps) save.StarsCollected = 3;
                else if (saves.TwoStarSteps >= LogicVariables.Steps) save.StarsCollected = 2;
                else if (saves.OneStarSteps >= LogicVariables.Steps) save.StarsCollected = 1;
            }

            save.NoHeadPushAchievement |= !LogicVariables.HeadPushHappened;
            if (save.PersonalMinimalSteps == 0) save.PersonalMinimalSteps = LogicVariables.Steps;
            else save.PersonalMinimalSteps = Math.Min(LogicVariables.Steps, save.PersonalMinimalSteps);

            save.BunnyKilled = save.BunnyKilled || LogicVariables.bunnyKilled;
        }

        public static void LoadEditor()
        {
            LevelChangedAfterSuccesfulTry();
        }

        public static void LevelChangedAfterSuccesfulTry() // block placed ect.
        {
            InProgress = null;
        }



        public static bool SaveLevel() // editor save()
        {
            // create level name systematically
            string LevelName;
            if (LevelMetaData.Metas.Count == 0) LevelName = "0";
            else LevelName = (int.Parse(LevelMetaData.Metas.Last().Key) + 1).ToString();

            if (InProgress == null) return false; // nem csalok teszteles miatt
            LevelMetaData.Metas[LevelName] = InProgress;
            CurrectLevelData.SaveLevel(LevelName);
            InProgress = null;
            return true;
        }

        public static void TryStarted()
        {
            CurrectLevelData.SaveLevel("../inEdit"); // for editor
        }

        public static bool LoadLevel(string levelName) // game -> select -> load() / level Editor/ import
        {
            bool ret;

            LogicVariables.LevelName = levelName;
            ret = CurrectLevelData.LoadLevel(levelName);

            return ret;
        }
    }
}