﻿using Models;
using Models.descendants.ByInstance;
using Models.descendants.ByModel;
using Models.imported;
using Repository;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Linq;
using System.Numerics;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Logic.GameLogics
{
    internal static class MoveLogic // move logically
    {
        public static float MoveSpeed = 1;
        public static float WinMoveSpeed = 3;

        //check:

        //death wish

        //canClimbInto

        //apple

        //black apple

        //goal

        //push

        //obsticle

        static List<InstanceTileData> puhedItems = new List<InstanceTileData>(2);
        static SnakeHead head;
        static Vector2Int dir;
        static bool eat;
        static bool shrink;
        static bool digest;
        static bool winMove;

        static float movePercent = 0;
        static SnakeBody? WildBody = null;

        static void ResetVars(Vector2Int direction, SnakeHead Head)
        {
            puhedItems.Clear();
            head = Head;
            dir = direction;
            digest = false;
            eat = false;
            shrink = false;
            movePercent = 0;
            WildBody = null;
            winMove = false;
        }


        public static bool MovePossible(Vector2Int direction, SnakeHead Head) // return "canMove" is stronger than winmove
        {
            if (direction.magnitude != 1) throw new ArgumentException("direction pram. is (0,1),(0, -1),(1,0) or (-1,0)");

            ResetVars(direction, Head);

            bool mayKill = false;

            Vector2Int aim = Head.MapPosXY + direction;
            if (CurrectLevelData.OutsideOfMap(aim)) return false;

            List<InstanceTileData> obsticles = CurrectLevelData.Data.Map[aim.x, aim.y];

            if (obsticles.Count == 0) return true;

            foreach (var ob in obsticles)
            {
                StaticTileData? obs_data = ob.StaticTileData;

                if (ob is ColoredInstanceTileData i && ob is not SnakeHead && ob is not SnakeBody && i.OwnerNum != Head.OwnerNum) continue;
                if (obs_data == null) continue; // inactive STD

                if (!SingleCheck(direction, ref mayKill, obs_data, aim)) return false;
            }

            // if program here, the snake can move!

            Head.GravityData.GotDestroyed = mayKill;
            if (digest) PreDigest();
            return true;
        }


        static bool SingleCheck(Vector2Int direction, ref bool mayKill, StaticTileData ob, Vector2Int aim)
        {
            bool ret;

            if (ob.kills)
                mayKill = true; // death wish


            else if (ob.eatable)
            {
                digest = true;
                if (ob.ID == "Apple") eat = true;
                else if (ob.ID == "BlackApple") shrink = true;
            }
            

            else if (ob.pushable) // push
            {
                Vector2Int aim2 = aim + direction;
                if (CurrectLevelData.OutsideOfMap(aim2)) return false; // would push it out

                List<InstanceTileData> obsticle2 = CurrectLevelData.Data.Map[aim2.x, aim2.y];

                bool fits = obsticle2.Count == 0 || obsticle2.All(ob2 => ob2.StaticTileData.CanBePushedIntoThis.Contains(ob.ID));
                if (fits)
                {
                    if (ob.ID == "SnakeHead") LogicVariables.HeadPushHappened = true;
                    puhedItems.Add(CurrectLevelData.GetFromMap(aim, ob.ID));
                }
                else return false;
            }

            else if (ob.ID == "Goal") // goal
            {
                //mayKill = true; // snake gets removed after leaving
                winMove = true;
            }

            else if (!ob.snakeCanClimbInto) return false; // obsticle


            return true;
        }







        static void MoveSnake(float percent, Vector2Int direction)
        {
            Vector2Int prevBodyMapXY = head.MapPosXY; // Store head's initial position
            MoveTile(head, percent, direction); // Move head first

            Vector2Int nextPos;
            foreach (var body in head.bodies)
            {
                nextPos = body.MapPosXY; // Store current position before it gets updated
                MoveTile(body, percent, prevBodyMapXY - body.MapPosXY); // Move body to where the preceding part was
                prevBodyMapXY = nextPos; // Update prevBodyMapXY to the stored position
            }
        }

        static void MoveTile(InstanceTileData tile, float precent, Vector2Int direction)
        {
            if (movePercent != 1) // move
            {
                tile.floatPos += direction * precent;
            }
            else
            {
                CurrectLevelData.MoveOnMap(tile, tile.MapPosXY + direction);
                tile.floatPos = new Vector2(tile.MapPosXY.x, tile.MapPosXY.y);
            }
        }

        public static bool Move(float dt)
        {
            float percent = (winMove ? WinMoveSpeed : MoveSpeed) * dt;
            percent = Math.Clamp(percent, 0, 1); // Ensure percent does not exceed 1 or drop below 0

            movePercent += percent;
            movePercent = Math.Min(movePercent, 1); // Ensure movePercent does not exceed 1

            if (winMove)
            {
                return WinMove(percent);
            }

            if (shrink)
            {
                MoveTile(WildBody, percent, WildDirection);
            }

            foreach (var pushedItem in puhedItems)
            {
                MoveTile(pushedItem, percent, dir);
            }

            MoveSnake(percent, dir);

            if (movePercent >= 1) // Check if the movement is complete
            {
                movePercent = 0; // Reset for next movement cycle
                if (digest) PostDigest();
                return true;
            }
            return false;
        }
        

        static bool WinMove(float precent)
        {
            MoveSnake(precent, dir);
            if (movePercent != 1) return false;

            if (dir != Vector2Int.zero) // first move finished
            {
                dir = Vector2Int.zero;
                CurrectLevelData.RemoveFromMap(head);
            }
            else // n.th move finished
            {
                CurrectLevelData.RemoveFromMap(head.bodies[0]);
                head.bodies.RemoveAt(0);
            }
            if (head.bodies.Count == 0) // last move finished
            {
                DestroyLogic.DestroyAnyObject(head);
                return true;
            }
            return false;
        }



        static Vector2Int WildDirection;

        static void PostDigest()
        {
            var eatPlace = CurrectLevelData.Data.Map[head.MapPosXY.x, head.MapPosXY.y];
            for (int i = 0; i < eatPlace.Count; i++)
            {
                var item = eatPlace[i];
                StaticTileData? data = item.StaticTileData;

                if (item is ColoredInstanceTileData x && x.OwnerNum != head.OwnerNum) continue;
                if (data == null) continue;
                if (data.eatable)
                {
                    DestroyLogic.DestroyAnyObject(item);
                    i--;
                }
            }

            if (shrink) DestroyLogic.DestroyAnyObject(WildBody);
            if (eat) head.bodies.Add(WildBody);

        }
        
        static void PreDigest()
        {
            if (shrink)
            {
                if (head.bodies.Count == 0)
                {
                    head.GravityData.GotDestroyed = true;
                    shrink = false;
                    return;
                }
                //if (head.bodies.Count == 1) head.StaticTileData.pushable = true; // make it pushable

                WildBody = head.bodies[head.bodies.Count - 1];
                head.bodies.RemoveAt(head.bodies.Count - 1);

                // wildDirection
                if (head.bodies.Count == 0) WildDirection = head.MapPosXY - WildBody.MapPosXY + dir;
                else if (head.bodies.Count == 1) WildDirection = head.MapPosXY - WildBody.MapPosXY;
                else WildDirection = head.bodies[head.bodies.Count - 2].MapPosXY - WildBody.MapPosXY;

                // to make it go under the body before it
                CurrectLevelData.MoveOnMap(WildBody, WildBody.MapPosXY + WildDirection);
            }
            if (eat)
            {
                if (head.bodies.Count == 0)
                {
                    WildBody = new SnakeBody(head.MapPosXY, head.OwnerNum, head.bodies.Count+1);
                }
                else
                {
                    WildBody = new SnakeBody(head.bodies[head.bodies.Count - 1].MapPosXY, head.OwnerNum, head.bodies.Count+1);
                }
                CurrectLevelData.AddToMap(WildBody);
                //head.StaticTileData.pushable = false;
            }
        }








    }
}
