﻿using Models;
using Models.descendants.ByInstance;
using Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logic.GameLogics
{
    internal static class DestroyLogic
    {

        static void DestroyGravityObject(InstanceTileData gravObj) // gravityObject
        {
            if (gravObj is SnakeHead)
            {
                SnakeHead head = (SnakeHead)gravObj;
                foreach (SnakeBody body in head.bodies)
                {
                    CurrectLevelData.RemoveFromMap(body);
                }
            }
            CurrectLevelData.RemoveFromMap(gravObj);
        }

        public static void DestroyAnyObject(InstanceTileData tile)
        {
            if (tile.StaticTileData.gravitable) DestroyGravityObject(tile);
            else CurrectLevelData.RemoveFromMap(tile);
        }
    }
}
