﻿using Models;
using Models.descendants.ByInstance;
using Models.imported;
using Repository;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Reflection;
using System.Reflection.PortableExecutable;
using System.Text;
using System.Threading.Tasks;

namespace Logic.GameLogics
{
    internal static class FallLogic
    {
        public static float FallStarterVelocity = 1;
        public static float FallAccel = 1;
        static float CurrectFallSpeed = 1;

        static float fallMade;
        static bool finishedFalling;


        public static bool Allfix;

        public static void FallOnMapArray()
        {
            Allfix = true;
            fallMade = 0;
            finishedFalling = false;
            CurrectFallSpeed = FallStarterVelocity;

            List<InstanceTileData> modified = new List<InstanceTileData>();


            for (int X = 0; X < 30; X++)
            {
                for (int Y = 0; Y < 20; Y++)
                {
                    for (int Z = 0; Z < CurrectLevelData.Data.Map[X, Y].Count; Z++)
                    {
                        var item = CurrectLevelData.Data.Map[X, Y][Z];

                        if (!item.StaticTileData.gravitable) continue;

                        if (item.GravityData.Fix) continue;
                        Allfix = false;

                        if (modified.Contains(item)) // prevent infinite put more down
                        {
                            modified.Remove(item);
                            continue;
                        }

                        item.GravityData.fallCount++;

                        modified.Add(item); // by ref
                        CurrectLevelData.RemoveFromMap(item);
                        item.MapPosXY += Vector2Int.ArrayDown;
                        if (!item.GravityData.GotDestroyed) CurrectLevelData.AddToMap(item);
                        else if (item is SnakeHead) LogicVariables.GameEndsDeath = true;


                        if (item is SnakeHead)
                        {
                            foreach (SnakeBody body in ((SnakeHead)item).bodies)
                            {
                                CurrectLevelData.RemoveFromMap(body);
                                body.MapPosXY += Vector2Int.ArrayDown;
                                if (!item.GravityData.GotDestroyed) CurrectLevelData.AddToMap(body);
                            }
                        }
                    }
                }
            }


        }

        public static bool Fall(float dt)
        {
            float FallnUnits = CurrectFallSpeed*dt;
            fallMade += FallnUnits;

            finishedFalling = true;
            foreach (var l in CurrectLevelData.Data.Map)
            {
                foreach (var item in l)
                {
                    if (!item.StaticTileData.gravitable) continue;

                    if (item.GravityData.fallCount == 0) continue;
                    finishedFalling = false;

                    fall(item, item.GravityData.fallCount, FallnUnits);
                }
            }

            CurrectFallSpeed += FallAccel*dt;
            return !finishedFalling;
        }

        static void fall(InstanceTileData tile, int fallCount, float fallUnits)
        {
            tile.floatPos += Vector2Int.ArrayDown * fallUnits;

            if (tile is SnakeHead)
            {
                foreach (var body in ((SnakeHead)tile).bodies)
                {
                    body.floatPos += Vector2Int.ArrayDown * fallUnits;
                }
            }

            if (fallMade >= fallCount)
            {
                tile.floatPos = new Vector2(tile.MapPosXY.x, tile.MapPosXY.y);
                tile.GravityData.fallCount = 0; // Reset fall count

                if (tile is SnakeHead)
                {
                    foreach (var body in ((SnakeHead)tile).bodies)
                    {
                        tile.floatPos = new Vector2(tile.MapPosXY.x, tile.MapPosXY.y);
                    }
                }
            }
        }
    }
}
