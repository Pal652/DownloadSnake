﻿using Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logic.GameLogics
{
    public static class LogicVariables
    {
        public static string SaveName = "save"; //^^^^
        public static int PlayerNum;
        public static string LevelName;

        public static int Steps;
        public static bool bunnyKilled; // not implemented yet
        public static bool GameEndsDeath;

        public static bool HeadPushHappened;

        public static int MaxSteps;

        public static int Seed;
        public static bool Win
        {
            get
            {
                return !GameEndsDeath && CurrectLevelData.PlayerNum == 0;
            }
        }
    }
}
