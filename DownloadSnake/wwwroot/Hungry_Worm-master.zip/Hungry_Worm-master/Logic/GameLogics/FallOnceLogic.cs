﻿using Models;
using Models.descendants.ByInstance;
using Models.imported;
using Repository;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Logic.GameLogics
{
    internal static class FallOnceLogic // check if the gravitable items are fix (set FixE, fallout and death under)
    {





        public static void FixCheckForAll()
        {
            SetUnfix();

            foreach (var l in CurrectLevelData.Data.Map)
            {
                foreach (var item in l)
                {
                    if (!item.StaticTileData.gravitable) continue;

                    if (item.GravityData.GotDestroyed) continue;

                    if (item is SnakeHead) FixSnakeCheck((SnakeHead)item);
                    else FixTileCheck(item, item.MapPosXY);
                }
            }
        }

        static void SetUnfix()
        {
            foreach (var l in CurrectLevelData.Data.Map)
            {
                foreach (var item in l)
                {
                    if (!item.StaticTileData.gravitable) continue;

                    item.GravityData.Fix = false;
                    item.GravityData.Examined = false;
                    item.GravityData.UnderExamination = false;
                    if (item is SnakeHead) ((SnakeHead)item).DeathUnder = false;
                }
            }
        }

        static void SetupUnder(Vector2Int pos, InstanceTileData item, out Vector2Int under, out List<InstanceTileData> underItems, out bool fallsOut)
        {
            under = pos + Vector2Int.ArrayDown; // under is bigger num
            fallsOut = false;

            if (CurrectLevelData.OutsideOfMap(under)) { underItems = new List<InstanceTileData>(); fallsOut = true; }
            else underItems = CurrectLevelData.Data.Map[under.x, under.y];
            underItems = underItems.ConvertAll(e => (e is SnakeBody)? CurrectLevelData.BodyToHead(e) : e);

            underItems.RemoveAll(e => e.ModelID == "null");

            // body under the same snakes's body
            //item = (item is SnakeBody) ? CurrectLevelData.BodyToHead(item) : item; // auto
            if (item is SnakeHead)
            {
                underItems.RemoveAll(e => (e is SnakeHead && ((SnakeHead)item).OwnerNum == ((SnakeHead)e).OwnerNum));
                underItems.RemoveAll(e => (e is ColoredInstanceTileData && e is not SnakeHead && ((ColoredInstanceTileData)e).OwnerNum != ((SnakeHead)item).OwnerNum));
            }
        }

        static void FixSnakeCheck(SnakeHead head)
        {
            //SetupUnder(head.MapPosXY, out Vector2Int under, out InstanceTileData? underItem);
            if (head.GravityData.Examined) return;

            head.GravityData.UnderExamination = true; // fix or under examination
            FixTileCheck(head, head.MapPosXY);
            foreach (var body in head.bodies)
            {
                FixTileCheck(head, body.MapPosXY);
                if (head.GravityData.Fix) break;
            }
            if (!head.GravityData.Fix) // at the end not fix
            {
                head.GravityData.GotDestroyed |= head.DeathUnder;
            }

            head.GravityData.UnderExamination = false;
            head.GravityData.Examined = true;
        }

        static void FixTileCheck(InstanceTileData item, Vector2Int coords)
        {
            if (item.GravityData.Examined) return; // examined / under examination

            if (item.ModelID == "null" || item.StaticTileData.gravitable == false) // double state (Gravitable, in an Ungravitable sate)
            {
                item.GravityData.Fix = true;
                item.GravityData.Examined = true;
            }

            SetupUnder(coords, item, out Vector2Int under, out List<InstanceTileData> underItems, out bool fallsOut);

            if (fallsOut)
            {
                if (item is SnakeHead) ((SnakeHead)item).DeathUnder = true;
                else item.GravityData.GotDestroyed = true;
            }


            foreach (var underItem in underItems)
            {
                // setup object killer bools
                if (item is SnakeHead && underItem.StaticTileData.kills)
                {
                    ((SnakeHead)item).DeathUnder = true;
                    continue; // not fix if kills
                }


                if (underItem.StaticTileData.gravitable == false) // fix is under
                {
                    if (!underItem.StaticTileData.canFallTroughID.Contains(item.ModelID)) // holds this
                    {
                        item.GravityData.Fix = true;
                        break;
                    }
                }
                else // gravity item under
                {
                    if (underItem.GravityData.UnderExamination)
                    {
                        item.GravityData.Fix = true; // break circle
                        break;
                    }
                    item.GravityData.UnderExamination = true;

                    // check under
                    if (underItem is SnakeHead) FixSnakeCheck((SnakeHead)underItem);
                    else FixTileCheck(underItem, underItem.MapPosXY);

                    item.GravityData.Fix = underItem.GravityData.Fix;
                    if (item.GravityData.Fix) break;
                }
            }
            if (item is not SnakeHead)
            {
                item.GravityData.UnderExamination = false;
                item.GravityData.Examined = true;
            }
        }


    }
}
