﻿using Logic.GameLogics;
using Models;
using Models.descendants.ByInstance;
using Models.imported;
using Repository;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Logic
{
    public static class LevelEditorLogic
    {
        public static List<InstanceTileData>[,] Map
        {
            get
            {
                return CurrectLevelData.Data.Map;
            }
        }

        public static void PlaceBlock(Vector2Int posXY, string ModelID, int? colornum = null) // colors in Skins.snakeColors[n][0]
        {
            InstanceTileData d;
            if (colornum == null) d = new InstanceTileData(ModelID, posXY);
            else d = new ColoredInstanceTileData(ModelID, posXY, (int)colornum);

            CurrectLevelData.AddToMap(d);
        }

        public static void Wipe()
        {
            CurrectLevelData.Wipe();
        }

        public static bool RemoveBlock(int row, int column)
        {
            if (CurrectLevelData.Data.Map[row, column].Count == 0) return false;
            var d = CurrectLevelData.Data.Map[row, column].First();

            if (d.ModelID == "SnakeHead" || d.modelID == "SnakeBody") return false;

            CurrectLevelData.RemoveFromMap(d);
            return true;
        }

        /*
        static void removeSnakeHead(SnakeHead d)
        {

            // remove in snakeHeads
            if (d.OwnerNum != CurrectLevelData.GetHead(CurrectLevelData.PlayerNum-1).OwnerNum) // not last snake removed
            {
                d.OwnerNum = -1;
                CurrectLevelData.GetHead(CurrectLevelData.PlayerNum-1).OwnerNum = d.OwnerNum;
                    foreach (var body in CurrectLevelData.GetHead(CurrectLevelData.PlayerNum - 1).bodies) 
                    body.OwnerNum = d.OwnerNum;
            }
            


            if (d.bodies.Count != 0) removeSnakeBody(d.bodies[0]); // remove everything from body 0
        }

        static void removeSnakeBody(SnakeBody d) // remove bodies after
        {
            int BodyIndex = 0;
            bool removeFrom = false;
            foreach (SnakeBody body in CurrectLevelData.BodyToHead(d).bodies) // remove bodies from map (not d)
            {
                if (removeFrom) CurrectLevelData.RemoveFromMap(body);
                if (body == d) removeFrom = true;
                else BodyIndex++;
            }
            CurrectLevelData.BodyToHead(d).bodies.RemoveRange(BodyIndex, CurrectLevelData.BodyToHead(d).bodies.Count - BodyIndex); // remove bodies from head's list (d too)
        }
        */

        //static bool placingSnake;
        static SnakeHead? currectHead;
        public static bool PlaceSnake(Vector2Int posXY, bool head)
        {
            ;
            if (!head && CurrectLevelData.GetHead(CurrectLevelData.PlayerNum-1).bodies.Count != 0 && (CurrectLevelData.GetHead(CurrectLevelData.PlayerNum-1).bodies.Last().MapPosXY - posXY).magnitude != 1) return false; // non neighbours

            if (head) // head
            {
                currectHead = new SnakeHead(posXY, CurrectLevelData.PlayerNum);
                CurrectLevelData.AddToMap(currectHead);
            }
            else // body
            {
                SnakeBody d = new SnakeBody(posXY, currectHead.OwnerNum, currectHead.bodies.Count+1);
                currectHead.bodies.Add(d);
                CurrectLevelData.AddToMap(d);
            }
            

            return true;
        }


    }
}
